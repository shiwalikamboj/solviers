/*============ Build our products data ==============*/

export const productsData = [
  {
    id: 1,
    title: "Country Living Divan Bed & Headboard",
    price: 2000,
    imageUrl:
      "./images/2000$_country-living-thirlmere-divan-bed-and-headboard.jpg",
  },

  {
    id: 2,
    title: "Luxury Divan Base",
    price: 300,
    imageUrl: "./images/300$_luxury-divan-base.jpg",
  },

  {
    id: 3,
    title: "Silent night Divan Base",
    price: 300,
    imageUrl: "./images/300$_silentnigight-divan-base.jpg",
  },

  {
    id: 4,
    title: "Tempur Queen Original Neck Pillow Firm V3",
    price: 95,
    imageUrl: "./images/95$_tempur-queen-original-neck-pillow-firm-v3.jpg",
  },

  {
    id: 5,
    title: "Country Living Rivington Divan Bed And Headboard",
    price: 3500,
    imageUrl:
      "./images/3500$_country-living-rivington-divan-bed-and-headboard.jpg",
  },

  {
    id: 6,
    title: "Dreams Soft And Bouncy Pillow Protector Pair",
    price: 12,
    imageUrl: "./images/12$_dreams-soft-and-bouncy-pillow-protector-pair.jpg",
  },

  {
    id: 7,
    title: "Flaxby Sprung Base",
    price: 500,
    imageUrl: "./images/500$_flaxby-sprung-base.jpg",
  },

  {
    id: 8,
    title: "Luxury Ottoman Base",
    price: 500,
    imageUrl: "./images/500$_luxury-ottoman-base.jpg",
  },

  {
    id: 9,
    title: "Tempur Cloud Pillow",
    price: 129,
    imageUrl: "./images/129$_tempur-cloud-pillow.jpg",
  },

  {
    id: 10,
    title: "Silentnight Ottoman Base",
    price: 650,
    imageUrl: "./images/650$_silentnight-ottoman-base.jpg",
  },

  {
    id: 11,
    title: "Therapur Shallow Ottoman Base",
    price: 700,
    imageUrl: "./images/700$_therapur-shallow-ottoman-base.jpg",
  },

  {
    id: 12,
    title: "Dreams Latex Pillow",
    price: 119,
    imageUrl: "./images/119$-dreams-latex-pillow.jpg",
  },

  {
    id: 13,
    title: "Sleepeezee Drawer Divan Base",
    price: 400,
    imageUrl: "./images/400$_sleepeezee-drawer-divan-base.jpg",
  },

  {
    id: 14,
    title: "Therapur Shallow Divan Base",
    price: 500,
    imageUrl: "./images/500$_therapur-shallow-divan-base.jpg",
  },

  {
    id: 15,
    title: "Classic Ottoman Base",
    price: 350,
    imageUrl: "./images/350$_classic-ottoman-base.jpg",
  },
];
